import Pyro4

@Pyro4.expose
class StringConcatenationServer:
    def concatenate_strings(self, str1, str2):
        result = str1 + str2
        return result

def main():
    daemon = Pyro4.Daemon()  # Create a Pyro daemon
    ns = Pyro4.locateNS()  # Locate the Pyro nameserver

    server = StringConcatenationServer() 
    uri = daemon.register(server) 
    ns.register("string.concatenation", uri) 

    print("Server URI:", uri) 

    # Writing URI to file is optional
    with open("server_uri.txt", "w") as f: 
        f.write(str(uri)) 

    print("Server is ready. Waiting for requests...")
    daemon.requestLoop() 

if __name__ == "__main__":
    main()